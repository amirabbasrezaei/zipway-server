-- AlterTable
ALTER TABLE "Ride" ALTER COLUMN "Status" DROP NOT NULL;
